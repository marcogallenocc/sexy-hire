/****credentials.js***/

module.exports = {cookieSecret: 'El bailecito arabito'}